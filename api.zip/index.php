<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/cors.php';
require_once __DIR__ . '/includes/response.php';

header('Content-Type: application/json');

// Simple router
$requestUri = $_SERVER['REQUEST_URI'];
$requestMethod = $_SERVER['REQUEST_METHOD'];

// Remove query string and leading slash
$path = strtok($requestUri, '?');
$path = trim($path, '/');

// API routes
$routes = [
    'POST /api/auth/signup' => 'api/auth/signup.php',
    'POST /api/auth/login' => 'api/auth/login.php',
    'POST /api/auth/send-otp' => 'api/auth/send-otp.php',
    'POST /api/auth/verify-otp' => 'api/auth/verify-otp.php',
    'POST /api/auth/refresh' => 'api/auth/refresh.php',
    'POST /api/auth/logout' => 'api/auth/logout.php'
];

$routeKey = $requestMethod . ' /' . $path;

if (isset($routes[$routeKey])) {
    require_once __DIR__ . '/' . $routes[$routeKey];
} else {
    // Default response for root path
    if ($path === '' || $path === 'api') {
        ApiResponse::success([
            'name' => 'MicroNest Auth API',
            'version' => '1.0.0',
            'endpoints' => [
                'POST /api/auth/signup' => 'Create new user account',
                'POST /api/auth/login' => 'User login',
                'POST /api/auth/send-otp' => 'Send email OTP',
                'POST /api/auth/verify-otp' => 'Verify email OTP',
                'POST /api/auth/refresh' => 'Refresh access token',
                'POST /api/auth/logout' => 'User logout'
            ]
        ], 'MicroNest Authentication API');
    } else {
        ApiResponse::notFound('Endpoint not found');
    }
}
?>
