<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include required files
require_once '../config/database.php';
require_once '../models/User.php';
require_once '../models/Auth.php';
require_once '../models/EmailService.php';
require_once '../utils/JWTUtil.php';
require_once '../utils/ResponseUtil.php';

// Get request method and URI
$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = explode('/', trim($uri, '/'));

// Remove 'api' from path if present
if ($path[0] === 'api') {
    array_shift($path);
}

// Route the request
try {
    switch ($path[0]) {
        case 'auth':
            handleAuthRoutes($method, $path);
            break;
        case 'users':
            handleUserRoutes($method, $path);
            break;
        case 'groups':
            handleGroupRoutes($method, $path);
            break;
        case 'contributions':
            handleContributionRoutes($method, $path);
            break;
        case 'loans':
            handleLoanRoutes($method, $path);
            break;
        default:
            ResponseUtil::sendError('Endpoint not found', 404);
    }
} catch (Exception $e) {
    ResponseUtil::sendError('Internal server error: ' . $e->getMessage(), 500);
}

function handleAuthRoutes($method, $path) {
    $auth = new Auth();
    
    switch ($path[1]) {
        case 'login':
            if ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->login($data['email'], $data['password']);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'signup':
            if ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->signup($data);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'send-otp':
            if ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->sendEmailOTP($data['email']);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'verify-otp':
            if ($method === 'POST') {
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->verifyEmailOTP($data['email'], $data['otp']);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'refresh':
            if ($method === 'POST') {
                $headers = getallheaders();
                $refreshToken = $headers['Authorization'] ?? '';
                $refreshToken = str_replace('Bearer ', '', $refreshToken);
                
                $result = $auth->refreshToken($refreshToken);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'logout':
            if ($method === 'POST') {
                $headers = getallheaders();
                $accessToken = $headers['Authorization'] ?? '';
                $accessToken = str_replace('Bearer ', '', $accessToken);
                
                $result = $auth->logout($accessToken);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        default:
            ResponseUtil::sendError('Auth endpoint not found', 404);
    }
}

function handleUserRoutes($method, $path) {
    // Verify JWT token first
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    
    if (empty($token)) {
        ResponseUtil::sendError('Authorization token required', 401);
        return;
    }
    
    $jwtUtil = new JWTUtil();
    $decoded = $jwtUtil->verifyToken($token);
    
    if (!$decoded) {
        ResponseUtil::sendError('Invalid or expired token', 401);
        return;
    }
    
    $user = new User();
    
    switch ($path[1]) {
        case 'profile':
            if ($method === 'GET') {
                $result = $user->getProfile($decoded->user_id);
                echo json_encode($result);
            } elseif ($method === 'PUT') {
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $user->updateProfile($decoded->user_id, $data);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        case 'trust-score':
            if ($method === 'GET') {
                $result = $user->getTrustScore($decoded->user_id);
                echo json_encode($result);
            } else {
                ResponseUtil::sendError('Method not allowed', 405);
            }
            break;
            
        default:
            ResponseUtil::sendError('User endpoint not found', 404);
    }
}

function handleGroupRoutes($method, $path) {
    // Verify JWT token first
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    
    if (empty($token)) {
        ResponseUtil::sendError('Authorization token required', 401);
        return;
    }
    
    $jwtUtil = new JWTUtil();
    $decoded = $jwtUtil->verifyToken($token);
    
    if (!$decoded) {
        ResponseUtil::sendError('Invalid or expired token', 401);
        return;
    }
    
    // Group routes implementation will go here
    ResponseUtil::sendError('Group endpoints not implemented yet', 501);
}

function handleContributionRoutes($method, $path) {
    // Verify JWT token first
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    
    if (empty($token)) {
        ResponseUtil::sendError('Authorization token required', 401);
        return;
    }
    
    $jwtUtil = new JWTUtil();
    $decoded = $jwtUtil->verifyToken($token);
    
    if (!$decoded) {
        ResponseUtil::sendError('Invalid or expired token', 401);
        return;
    }
    
    // Contribution routes implementation will go here
    ResponseUtil::sendError('Contribution endpoints not implemented yet', 501);
}

function handleLoanRoutes($method, $path) {
    // Verify JWT token first
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? '';
    $token = str_replace('Bearer ', '', $token);
    
    if (empty($token)) {
        ResponseUtil::sendError('Authorization token required', 401);
        return;
    }
    
    $jwtUtil = new JWTUtil();
    $decoded = $jwtUtil->verifyToken($token);
    
    if (!$decoded) {
        ResponseUtil::sendError('Invalid or expired token', 401);
        return;
    }
    
    // Loan routes implementation will go here
    ResponseUtil::sendError('Loan endpoints not implemented yet', 501);
}
?> 