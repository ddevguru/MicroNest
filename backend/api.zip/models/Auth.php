<?php
require_once '../config/database.php';
require_once '../utils/JWTUtil.php';
require_once '../utils/ResponseUtil.php';

class Auth {
    private $conn;
    private $jwtUtil;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
        $this->jwtUtil = new JWTUtil();
    }
    
    public function login($email, $password) {
        try {
            // Check if user exists and email is verified
            $query = "SELECT id, full_name, email, username, password_hash, email_verified, status, trust_score 
                     FROM users WHERE email = ? AND status = 'active'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() == 0) {
                return ResponseUtil::error('Invalid email or password', 401);
            }
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Check if email is verified
            if (!$user['email_verified']) {
                return ResponseUtil::error('Please verify your email first', 401);
            }
            
            // Verify password
            if (!password_verify($password, $user['password_hash'])) {
                return ResponseUtil::error('Invalid email or password', 401);
            }
            
            // Generate JWT tokens
            $accessToken = $this->jwtUtil->generateAccessToken($user['id']);
            $refreshToken = $this->jwtUtil->generateRefreshToken($user['id']);
            
            // Store refresh token in database
            $this->storeRefreshToken($user['id'], $refreshToken);
            
            // Remove sensitive data
            unset($user['password_hash']);
            
            return ResponseUtil::success('Login successful', [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'user' => $user
            ]);
            
        } catch (Exception $e) {
            return ResponseUtil::error('Login failed: ' . $e->getMessage(), 500);
        }
    }
    
    public function signup($data) {
        try {
            // Validate required fields
            $requiredFields = ['full_name', 'email', 'username', 'password', 'phone', 'address'];
            foreach ($requiredFields as $field) {
                if (empty($data[$field])) {
                    return ResponseUtil::error("Field '$field' is required", 400);
                }
            }
            
            // Check if email already exists
            $query = "SELECT id FROM users WHERE email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$data['email']]);
            
            if ($stmt->rowCount() > 0) {
                return ResponseUtil::error('Email already registered', 400);
            }
            
            // Check if username already exists
            $query = "SELECT id FROM users WHERE username = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$data['username']]);
            
            if ($stmt->rowCount() > 0) {
                return ResponseUtil::error('Username already taken', 400);
            }
            
            // Hash password
            $passwordHash = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // Insert new user
            $query = "INSERT INTO users (full_name, email, username, password_hash, phone, address, profile_image, email_verified) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, FALSE)";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $data['full_name'],
                $data['email'],
                $data['username'],
                $passwordHash,
                $data['phone'],
                $data['address'],
                $data['profile_image'] ?? null
            ]);
            
            $userId = $this->conn->lastInsertId();
            
            // Get user data
            $query = "SELECT id, full_name, email, username, phone, address, profile_image, email_verified, trust_score 
                     FROM users WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Generate JWT tokens
            $accessToken = $this->jwtUtil->generateAccessToken($userId);
            $refreshToken = $this->jwtUtil->generateRefreshToken($userId);
            
            // Store refresh token
            $this->storeRefreshToken($userId, $refreshToken);
            
            return ResponseUtil::success('Account created successfully', [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'user' => $user
            ]);
            
        } catch (Exception $e) {
            return ResponseUtil::error('Signup failed: ' . $e->getMessage(), 500);
        }
    }
    
    public function sendEmailOTP($email) {
        try {
            // Check if user exists
            $query = "SELECT id, full_name FROM users WHERE email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() == 0) {
                return ResponseUtil::error('Email not found', 404);
            }
            
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Generate OTP
            $otp = $this->generateOTP();
            $expiresAt = date('Y-m-d H:i:s', strtotime('+10 minutes'));
            
            // Delete existing OTPs for this email
            $query = "DELETE FROM email_otps WHERE email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            
            // Store new OTP
            $query = "INSERT INTO email_otps (email, otp, expires_at) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email, $otp, $expiresAt]);
            
            // Send email using SMTP2GO
            $emailResult = $this->sendEmailViaSMTP2GO($email, $user['full_name'], $otp);
            
            if (!$emailResult['success']) {
                return ResponseUtil::error('Failed to send OTP email: ' . $emailResult['message'], 500);
            }
            
            return ResponseUtil::success('OTP sent successfully');
            
        } catch (Exception $e) {
            return ResponseUtil::error('Failed to send OTP: ' . $e->getMessage(), 500);
        }
    }
    
    public function verifyEmailOTP($email, $otp) {
        try {
            // Check if OTP exists and is valid
            $query = "SELECT id, expires_at FROM email_otps 
                     WHERE email = ? AND otp = ? AND used = FALSE AND expires_at > NOW()";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email, $otp]);
            
            if ($stmt->rowCount() == 0) {
                return ResponseUtil::error('Invalid or expired OTP', 400);
            }
            
            $otpRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Mark OTP as used
            $query = "UPDATE email_otps SET used = TRUE WHERE id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$otpRecord['id']]);
            
            // Mark user email as verified
            $query = "UPDATE users SET email_verified = TRUE, email_verified_at = NOW() WHERE email = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$email]);
            
            return ResponseUtil::success('Email verified successfully');
            
        } catch (Exception $e) {
            return ResponseUtil::error('OTP verification failed: ' . $e->getMessage(), 500);
        }
    }
    
    public function refreshToken($refreshToken) {
        try {
            // Verify refresh token
            $decoded = $this->jwtUtil->verifyRefreshToken($refreshToken);
            if (!$decoded) {
                return ResponseUtil::error('Invalid refresh token', 401);
            }
            
            // Check if refresh token exists in database
            $query = "SELECT id FROM user_tokens WHERE refresh_token = ? AND expires_at > NOW()";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$refreshToken]);
            
            if ($stmt->rowCount() == 0) {
                return ResponseUtil::error('Refresh token not found or expired', 401);
            }
            
            // Generate new tokens
            $accessToken = $this->jwtUtil->generateAccessToken($decoded->user_id);
            $newRefreshToken = $this->jwtUtil->generateRefreshToken($decoded->user_id);
            
            // Update refresh token in database
            $query = "UPDATE user_tokens SET refresh_token = ?, expires_at = ? WHERE refresh_token = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([
                $newRefreshToken,
                date('Y-m-d H:i:s', strtotime('+30 days')),
                $refreshToken
            ]);
            
            return ResponseUtil::success('Token refreshed successfully', [
                'access_token' => $accessToken,
                'refresh_token' => $newRefreshToken
            ]);
            
        } catch (Exception $e) {
            return ResponseUtil::error('Token refresh failed: ' . $e->getMessage(), 500);
        }
    }
    
    public function logout($accessToken) {
        try {
            // Verify access token
            $decoded = $this->jwtUtil->verifyAccessToken($accessToken);
            if (!$decoded) {
                return ResponseUtil::error('Invalid access token', 401);
            }
            
            // Remove refresh token from database
            $query = "DELETE FROM user_tokens WHERE user_id = ?";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$decoded->user_id]);
            
            return ResponseUtil::success('Logged out successfully');
            
        } catch (Exception $e) {
            return ResponseUtil::error('Logout failed: ' . $e->getMessage(), 500);
        }
    }
    
    private function generateOTP() {
        return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    }
    
    private function storeRefreshToken($userId, $refreshToken) {
        try {
            $expiresAt = date('Y-m-d H:i:s', strtotime('+30 days'));
            
            $query = "INSERT INTO user_tokens (user_id, access_token, refresh_token, expires_at) 
                     VALUES (?, ?, ?, ?)";
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$userId, '', $refreshToken, $expiresAt]);
            
        } catch (Exception $e) {
            throw new Exception('Failed to store refresh token: ' . $e->getMessage());
        }
    }
    
    private function sendEmailViaSMTP2GO($email, $fullName, $otp) {
        try {
            // SMTP2GO API configuration
            $apiKey = 'YOUR_SMTP2GO_API_KEY'; // Replace with your actual API key
            $apiUrl = 'https://api.smtp2go.com/v3/email/send';
            
            $emailData = [
                'api_key' => $apiKey,
                'to' => [$email],
                'sender' => 'noreply@micronest.com',
                'subject' => 'MicroNest - Email Verification OTP',
                'html_body' => $this->generateOTPEmailHTML($fullName, $otp),
                'text_body' => $this->generateOTPEmailText($fullName, $otp)
            ];
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($emailData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $responseData = json_decode($response, true);
                if (isset($responseData['data']['succeeded']) && $responseData['data']['succeeded'] == 1) {
                    return ['success' => true, 'message' => 'Email sent successfully'];
                } else {
                    return ['success' => false, 'message' => 'SMTP2GO API error'];
                }
            } else {
                return ['success' => false, 'message' => 'HTTP Error: ' . $httpCode];
            }
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    private function generateOTPEmailHTML($fullName, $otp) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='utf-8'>
            <title>Email Verification - MicroNest</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #52B788, #40916C); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                .otp-box { background: #52B788; color: white; padding: 20px; text-align: center; border-radius: 8px; margin: 20px 0; font-size: 24px; font-weight: bold; letter-spacing: 5px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>μN</h1>
                    <h2>Email Verification</h2>
                </div>
                <div class='content'>
                    <p>Hello $fullName!</p>
                    <p>Thank you for signing up with MicroNest. To complete your registration, please use the verification code below:</p>
                    <div class='otp-box'>$otp</div>
                    <p>This code will expire in 10 minutes for security reasons.</p>
                    <p>If you didn't request this verification, please ignore this email.</p>
                    <p>Best regards,<br>The MicroNest Team</p>
                </div>
            </div>
        </body>
        </html>
        ";
    }
    
    private function generateOTPEmailText($fullName, $otp) {
        return "
Email Verification - MicroNest

Hello $fullName!

Thank you for signing up with MicroNest. To complete your registration, please use the verification code below:

$otp

This code will expire in 10 minutes for security reasons.

If you didn't request this verification, please ignore this email.

Best regards,
The MicroNest Team

© 2024 MicroNest. All rights reserved.
        ";
    }
}
?> 